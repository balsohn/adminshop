package kr.co.batis;

import java.util.ArrayList;

public interface BoardDAO {

	
}
