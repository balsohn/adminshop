package kr.co.pension.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.datetime.joda.LocalDateParser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.pension.dao.ReserveDAO;
import kr.co.pension.dto.ReserveDTO;
import kr.co.pension.dto.RoomDTO;
import kr.co.pension.util.Utils;

@Controller
public class ReserveController {

	@Autowired
	private SqlSession sql;
	
	@RequestMapping("/reserve/reserve")
    public String reserve(Model model, HttpServletRequest request) {
        String yearParam = request.getParameter("year");
        String monthParam = request.getParameter("month");

        Calendar today = new GregorianCalendar();
        int currentYear = today.get(Calendar.YEAR);
        int currentMonth = today.get(Calendar.MONTH) + 1;
        int currentDay = today.get(Calendar.DAY_OF_MONTH);
        int year = (yearParam != null) ? Integer.parseInt(yearParam) : currentYear;
        int month = (monthParam != null) ? Integer.parseInt(monthParam) - 1 : currentMonth - 1;
        
        today.set(year, month, 1);
        int firstDayOfWeek = today.get(Calendar.DAY_OF_WEEK);
        int daysInMonth = today.getActualMaximum(Calendar.DAY_OF_MONTH);

        model.addAttribute("year", year);
        model.addAttribute("month", month + 1); // Calendar.MONTH는 0부터 시작하므로 1을 더해줍니다.
        model.addAttribute("firstDayOfWeek", firstDayOfWeek);
        model.addAttribute("daysInMonth", daysInMonth);
        model.addAttribute("currentYear", currentYear);
        model.addAttribute("currentMonth", currentMonth+1);
        model.addAttribute("currentDay", currentDay);

        ReserveDAO rdao = sql.getMapper(ReserveDAO.class);
        ArrayList<RoomDTO> rlist = rdao.getRooms();
        model.addAttribute("rdto", rlist);

        // 1일부터 마지막 날까지 모든 방의 예약 가능 여부를 0,1로써 저장 => map.put("일_방번호",예약 가능여부)
        HashMap<String, Integer> map = new HashMap<>();
        for (int i = 0; i < rlist.size(); i++) {
            for (int j = 1; j <= daysInMonth; j++) {
                String date = year + "-" + (month + 1) + "-" + j;
                int cnt;
                if (rdao.isCheck(date, rlist.get(i).getId())) {
                    cnt = 1;
                    map.put(j + "-" + rlist.get(i).getId(), cnt);
                } else {
                    cnt = 0;
                    map.put(j + "-" + rlist.get(i).getId(), cnt);
                }
            }
        }

        model.addAttribute("map", map);

        return "/reserve/reserve";
    }
	
	@RequestMapping("/reserve/reserveNext")
	public String reserveNext(HttpServletRequest request,Model model,HttpSession session,
			HttpServletResponse response) {
		
		if(session.getAttribute("userid")==null) {
			String originalURL = request.getRequestURL().toString() + "?" + request.getQueryString();
			Cookie cookie=new Cookie("url", originalURL);
			cookie.setMaxAge(600);
			cookie.setPath("/");
			response.addCookie(cookie);
			
			return "redirect:/member/login";
		} else {
		
		int year=Integer.parseInt(request.getParameter("year"));
		int month=Integer.parseInt(request.getParameter("month"));
		int day=Integer.parseInt(request.getParameter("day"));
		int id=Integer.parseInt(request.getParameter("id"));
				
		String date = String.format("%04d-%02d-%02d", year, month, day);

		model.addAttribute("date",date);
		
		ReserveDAO rdao=sql.getMapper(ReserveDAO.class);
		RoomDTO rdto=rdao.getRoom(id);
		
		rdto.setContent(rdto.getContent().replace("\r\n", "<br>"));
		String[] imgs=rdto.getRoomimg().split("/");
		
		rdto.setPrice2(Utils.comma(rdto.getPrice()));
		
		model.addAttribute("imgs",imgs);
		model.addAttribute("rdto", rdto);

		int suk=0;
 	    LocalDate xday=LocalDate.of(year, month, day);
 	    for(int i=1;i<=6;i++)
 	    {
 	    	// 8월 11일이 가능한지
 	    	if(rdao.isCheck(xday.toString(),id))
 	    	{
 	    		break;
 	    	}
 	    	else // 예약 가능
 	    	{
 	    		suk++;
 	    	}
 	    	// 날짜를 하루 증가시킨다.
 	    	
 	    	xday=xday.plusDays(1);
 	    	
 	    }
 	    model.addAttribute("suk",suk);
 	    
 	    
		model.addAttribute("rdto",rdto);
		model.addAttribute("date",date);
		
		return "/reserve/reserveNext";
		}
	}
	
	@RequestMapping("/reserve/reserveOk")
	public String reserveOk(ReserveDTO rdto,HttpSession session) {
		LocalDate dday=Utils.getDate(rdto.getInday(), rdto.getSuk());
		rdto.setOutday(dday.toString());
		
		// jumuncode를 생성해서 dto에 넣기
		String jumuncode="j"+Utils.dateToString();
		ReserveDAO rdao=sql.getMapper(ReserveDAO.class);
		int a=rdao.getNumber(jumuncode)+1;
		String b=String.format("%03d", a);
		jumuncode=jumuncode+b;
		rdto.setJumuncode(jumuncode);
		
		String userid=session.getAttribute("userid").toString();
		rdto.setUserid(userid);
		
		
		rdao.reserveOk(rdto);
		// 오늘날짜 기준으로 가장 높은 오른쪽에서 3자리 값을 가져오기
		
		return "redirect:/reserve/reserveView?jumuncode="+jumuncode;
	}
	
	@RequestMapping("/reserve/reserveView")
	public String reserveView(HttpServletRequest request, Model model) {
		String jumuncode=request.getParameter("jumuncode");
		ReserveDAO rdao=sql.getMapper(ReserveDAO.class);
		ReserveDTO rdto=rdao.reserveView(jumuncode);
		RoomDTO rdto2=rdao.getRoom(rdto.getRid());
		String price2=Utils.comma(rdto.getChgprice());
		
		model.addAttribute("price",price2);
		model.addAttribute("title",rdto2.getTitle());
		model.addAttribute("rdto",rdto);
		return "/reserve/reserveView";
	}
} 
