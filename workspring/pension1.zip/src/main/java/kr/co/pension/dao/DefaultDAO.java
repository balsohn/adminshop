package kr.co.pension.dao;

import java.util.ArrayList;

import kr.co.pension.dto.RoomDTO;

public interface DefaultDAO {
	public ArrayList<RoomDTO> getRooms();
}
