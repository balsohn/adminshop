package kr.co.pension.dao;

import java.util.ArrayList;
import java.util.HashMap;

import kr.co.pension.dto.InquiryDTO;
import kr.co.pension.dto.MemberDTO;
import kr.co.pension.dto.ReserveDTO;
import kr.co.pension.dto.RoomDTO;

public interface AdminDAO {
	public ArrayList<RoomDTO> list();
	public void writeOk(RoomDTO rdto);
	public ArrayList<InquiryDTO> getInquirys();
	public void inquiryOk(InquiryDTO idto);
	public ArrayList<HashMap> memberList();
	public ArrayList<ReserveDTO> reserveList();
	public void cancelRe(String state, String id);
}
